package com.infodart.sms;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class First_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_);
    }

    public void msgentry(View view) {
        startActivity(new Intent(First_Activity.this,MainActivity.class));
    }

    public void onemail(View view) {
        startActivity(new Intent(First_Activity.this,Email_Activity.class));

    }
}
