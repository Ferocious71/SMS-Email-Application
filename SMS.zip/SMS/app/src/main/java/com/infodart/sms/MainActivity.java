package com.infodart.sms;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button btn_send;
    TextInputEditText phone_number,msgs;
    private static final int Request_Read_Contacts=0;
    private static final int Request_Code_permission=2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        phone_number = findViewById(R.id.phonenumber);
        msgs= findViewById(R.id.message);
        btn_send = findViewById(R.id.btn_send);

        //  Permission checked
        String cpermission = Manifest.permission.SEND_SMS;
        try{
            if (ActivityCompat.checkSelfPermission(this,cpermission)!=
                    PackageManager.PERMISSION_GRANTED){

                ActivityCompat.requestPermissions(this,new String[]{cpermission},
                        Request_Code_permission);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }

        String spermission = Manifest.permission.INTERNET;
        try{
            if (ActivityCompat.checkSelfPermission(this,spermission)!=
                    PackageManager.PERMISSION_GRANTED){

                ActivityCompat.requestPermissions(this,new String[]{spermission},
                        Request_Code_permission);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    public void onmessage(View view) {

        String phonenumber=phone_number.getText().toString();
        if (phonenumber.isEmpty()){
            phone_number.setError("Phone Number cannot be empty");

        }else if (phonenumber.length() >10 || phonenumber.length() <10){
            phone_number.setError("Only Indian Sim Card Numbers");

        }else{
            SmsManager sms=SmsManager.getDefault();
            String msg=msgs.getText().toString();
            sms.sendTextMessage(phonenumber,null,msg,null,null);
            Toast.makeText(getApplicationContext(), "SMS sent.",
                    Toast.LENGTH_LONG).show();
        }
    }
}
