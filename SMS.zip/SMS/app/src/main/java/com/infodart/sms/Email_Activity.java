package com.infodart.sms;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class Email_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_);

        String sPermission= Manifest.permission.INTERNET;
        try{
            if (ActivityCompat.checkSelfPermission(this,sPermission)!=
                    PackageManager.PERMISSION_GRANTED){
                //ActivityCompat.requestPermissions(this,new String[]{cPermission},Request_Code_permission);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    public void sendEmail(View v){

        Log.i("send email","");
        String[] TO={""};
        String[] CC={""};

        Intent emailintent=new Intent(Intent.ACTION_SEND);
        emailintent.setData(Uri.parse("mail to:"));
        emailintent.setType("text/plain");
        emailintent.putExtra(Intent.EXTRA_EMAIL,TO);
        emailintent.putExtra(Intent.EXTRA_CC,CC);
        emailintent.putExtra(Intent.EXTRA_SUBJECT,"");
        emailintent.putExtra(Intent.EXTRA_TEXT,"");
        try{
            startActivity(Intent.createChooser(emailintent,
                    "Choose an Email client in your phone"));
        }
        catch (android.content.ActivityNotFoundException ex){
            Toast.makeText(this,"there is no email client",
                    Toast.LENGTH_LONG).show();
        }
    }
}

